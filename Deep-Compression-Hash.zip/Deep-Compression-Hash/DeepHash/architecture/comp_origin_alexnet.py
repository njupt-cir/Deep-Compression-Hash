import os
import tensorflow as tf
import numpy as np
from .utils import ConvGroupNorm

def comp_origin_alexnet_layers(img, batch_size, output_dim, stage, model_weights, with_tanh=True, val_batch_size=32):
    """

    :param img:
    :param batch_size:
    :param output_dim:
    :param stage:
    :param model_weights:
    :param with_tanh:
    :param val_batch_size:
    :return:
    """


    deep_param_img = {}
    train_layers = {'weights': [],
                    'biases': [],
                    'gamma': [],
                    'beta': []
                    }
    train_last_layer = {'weights': [],
                        'biases': [],
                        'gamma': [],
                        'beta': []
                        }
    print("loading img model from %s" % model_weights)
    net_data = dict(np.load(model_weights, encoding='bytes').item())
    print(list(net_data.keys()))

    centers = tf.Variable([-2.7752876, -4.6336412, -0.1840482, -1.3905534, 3.3731883, 1.3394068], name='centers', trainable=False)
    num_centers = centers.get_shape().as_list()[-1]

    # intput code: BCHW (B,64,32,32)
    with tf.name_scope('reshape_BCm1'):
        # reshape (B, C, h, w) to (B, C, m=h*w)
        x_shape_BCwh = tf.shape(img)

        B = x_shape_BCwh[0]  # B is not necessarily static
        C = int(img.shape[1])  # C is static
        img = tf.reshape(img, [B, C, -1])

        phi_hard = tf.one_hot(img, depth=num_centers, axis=-1, dtype=tf.float32)

        img = tf.reshape(tf.reduce_sum(phi_hard*centers, axis=3), x_shape_BCwh)

        # reshape to [B,H,W,C]
        img = tf.transpose(img, [0, 2, 3, 1])

    # img = tf.cast(tf.transpose(img, [0, 2, 3, 1]), tf.float32)

    # swap(2,1,0), bgr -> rgb
    # reshaped_image = tf.cast(img, tf.float32)[:, :, :, ::-1]
    # img = tf.cast(img, tf.float32)

    height = 27
    width = 27

    # Randomly crop a [height, width] section of each image
    with tf.name_scope('preprocess'):
        def train_fn():
            return tf.stack([tf.image.random_flip_left_right(each) for each in tf.unstack(img, batch_size)])

        def val_fn():
            unstacked = tf.unstack(img, val_batch_size)

            def distort(f): return tf.stack(
                [f(each) for each in unstacked])

            def distort_raw(): return distort(lambda x: x)

            def distort_flip_left_right(): return distort(tf.image.flip_left_right)
            def distort_flip_up_down(): return distort(tf.image.flip_up_down)
            def distort_transpose_image(): return distort(tf.image.transpose_image)

            distorted = tf.concat([distort_flip_left_right(),
                                   # distort_flip_up_down(),
                                   # distort_transpose_image(),
                                   distort_raw()],
                                  0)
            #
            # distorted = tf.stack([tf.random_crop(tf.image.random_flip_left_right(each), [height, width, 64])
            #                  for each in tf.unstack(img, val_batch_size)])

            return distorted



        distorted = tf.cond(stage > 0, val_fn, train_fn)

    # Conv1
    # Output 256, pad 1, kernel 3
    with tf.name_scope('conv1') as scope:
        if net_data['conv1'][0].shape == (1, 1, 64, 96):
            kernel = tf.Variable(net_data['conv1'][0], name='weights')
            biases = tf.Variable(net_data['conv1'][1], name='biases')
        else:
            kernel = tf.Variable(tf.random_normal([1, 1, 64, 96],
                                                  dtype=tf.float32,
                                                  stddev=1e-2), name='weights')
            biases = tf.Variable(tf.random_normal([96],
                                                dtype=tf.float32,
                                                stddev=1e-2), name='biases')

        conv = tf.nn.conv2d(distorted, kernel, [1, 1, 1, 1], padding='SAME')
        out = tf.nn.bias_add(conv, biases)
        conv1 = tf.nn.relu(out, name=scope)

        # tf.summary.histogram('/weights', kernel)
        # tf.summary.histogram('/biases', biases)
        # tf.summary.histogram('/gamma', gamma)
        # tf.summary.histogram('/beta', beta)

        deep_param_img['conv1'] = [kernel, biases]
        train_layers['weights'].append(kernel)
        train_layers['biases'].append(biases)

    # Pool1
    pool1 = tf.nn.max_pool(conv1,
                            ksize=[1, 6, 6, 1],
                            strides=[1, 1, 1, 1],
                            padding='VALID',
                            name='pool1')
    # print(pool1)
    # exit()
    # LRN1
    radius = 2
    alpha = 2e-05
    beta = 0.75
    bias = 1.0
    lrn1 = tf.nn.local_response_normalization(pool1,
                                              depth_radius=radius,
                                              alpha=alpha,
                                              beta=beta,
                                              bias=bias)

    # Conv2
    # Output 256, pad 2, kernel 5, group 2
    with tf.name_scope('conv2') as scope:
        kernel = tf.Variable(net_data['conv2'][0], name='weights')
        group = 2

        def convolve(i, k): return tf.nn.conv2d(
            i, k, [1, 1, 1, 1], padding='SAME')

        input_groups = tf.split(lrn1, group, 3)
        kernel_groups = tf.split(kernel, group, 3)
        output_groups = [convolve(i, k)
                         for i, k in zip(input_groups, kernel_groups)]
        # Concatenate the groups
        conv = tf.concat(output_groups, 3)

        biases = tf.Variable(net_data['conv2'][1], name='biases')
        out = tf.nn.bias_add(conv, biases)

        conv2 = tf.nn.relu(out, name=scope)

        # tf.summary.histogram('/weights', kernel)
        # tf.summary.histogram('/biases', biases)
        # tf.summary.histogram('/gamma', gamma)
        # tf.summary.histogram('/beta', beta)
        deep_param_img['conv2'] = [kernel, biases]
        train_layers['weights'].append(kernel)
        train_layers['biases'].append(biases)


    # Pool2
    pool2 = tf.nn.max_pool(conv2,
                           ksize=[1, 3, 3, 1],
                           strides=[1, 2, 2, 1],
                           padding='VALID',
                           name='pool2')

    # LRN2
    radius = 2
    alpha = 2e-05
    beta = 0.75
    bias = 1.0
    lrn2 = tf.nn.local_response_normalization(pool2,
                                              depth_radius=radius,
                                              alpha=alpha,
                                              beta=beta,
                                              bias=bias)

    # Conv3
    # Output 384, pad 1, kernel 3
    with tf.name_scope('conv3') as scope:
        kernel = tf.Variable(net_data['conv3'][0], name='weights')
        conv = tf.nn.conv2d(lrn2, kernel, [1, 1, 1, 1], padding='SAME')
        biases = tf.Variable(net_data['conv3'][1], name='biases')
        out = tf.nn.bias_add(conv, biases)

        conv3 = tf.nn.relu(out, name=scope)

        # tf.summary.histogram('/weights', kernel)
        # tf.summary.histogram('/biases', biases)
        # tf.summary.histogram('/gamma', gamma)
        # tf.summary.histogram('/beta', beta)
        deep_param_img['conv3'] = [kernel, biases]
        # deep_param_img['conv3'] = [kernel, biases]
        train_layers['weights'].append(kernel)
        train_layers['biases'].append(biases)

    # Conv4
    # Output 384, pad 1, kernel 3, group 2
    with tf.name_scope('conv4') as scope:
        kernel = tf.Variable(net_data['conv4'][0], name='weights')
        group = 2

        def convolve(i, k): return tf.nn.conv2d(
            i, k, [1, 1, 1, 1], padding='SAME')

        input_groups = tf.split(conv3, group, 3)
        kernel_groups = tf.split(kernel, group, 3)
        output_groups = [convolve(i, k)
                         for i, k in zip(input_groups, kernel_groups)]
        # Concatenate the groups
        conv = tf.concat(output_groups, 3)
        biases = tf.Variable(net_data['conv4'][1], name='biases')
        out = tf.nn.bias_add(conv, biases)

        conv4 = tf.nn.relu(out, name=scope)

        # tf.summary.histogram('/weights', kernel)
        # tf.summary.histogram('/biases', biases)
        # tf.summary.histogram('/gamma', gamma)
        # tf.summary.histogram('/beta', beta)
        deep_param_img['conv4'] = [kernel, biases]
        # deep_param_img['conv4'] = [kernel, biases]
        train_layers['weights'].append(kernel)
        train_layers['biases'].append(biases)

    # Conv5
    # Output 256, pad 1, kernel 3, group 2
    with tf.name_scope('conv5') as scope:
        kernel = tf.Variable(net_data['conv5'][0], name='weights')
        group = 2

        def convolve(i, k): return tf.nn.conv2d(
            i, k, [1, 1, 1, 1], padding='SAME')

        input_groups = tf.split(conv4, group, 3)
        kernel_groups = tf.split(kernel, group, 3)
        output_groups = [convolve(i, k)
                         for i, k in zip(input_groups, kernel_groups)]
        # Concatenate the groups
        conv = tf.concat(output_groups, 3)
        biases = tf.Variable(net_data['conv5'][1], name='biases')
        out = tf.nn.bias_add(conv, biases)

        conv5 = tf.nn.relu(out, name=scope)

        # tf.summary.histogram('/weights', kernel)
        # tf.summary.histogram('/biases', biases)

        # deep_param_img['conv5'] = [kernel, biases, gamma, beta]
        deep_param_img['conv5'] = [kernel, biases]
        train_layers['weights'].append(kernel)
        train_layers['biases'].append(biases)
        # train_layers['gamma'].append(gamma)
        # train_layers['beta'].append(beta)

    # Pool5
    pool5 = tf.nn.max_pool(conv5,
                           ksize=[1, 3, 3, 1],
                           strides=[1, 2, 2, 1],
                           padding='VALID',
                           name='pool5')

    # FC6
    # Output 4096
    with tf.name_scope('fc6'):
        shape = int(np.prod(pool5.get_shape()[1:]))
        # print(pool5.get_shape()[1:])
        fc6w = tf.Variable(net_data['fc6'][0], name='weights')
        fc6b = tf.Variable(net_data['fc6'][1], name='biases')
        pool5_flat = tf.reshape(pool5, [-1, shape])
        fc6l = tf.nn.bias_add(tf.matmul(pool5_flat, fc6w), fc6b)
        # fc6l = tf.matmul(pool5_flat, fc6w)
        # print(fc6l)

        # try:
        #     gamma = tf.Variable(net_data['fc6'][2], name='gamma')
        #     beta = tf.Variable(net_data['fc6'][3], name='beta')
        #     moving_mean = tf.Variable(net_data['fc6'][4], name='moving_mean')
        #     moving_variance = tf.Variable(net_data['fc6'][5], name='moving_variance')
        #     print('fc6 bn state: restore')
        # except:
        #     gamma = tf.Variable(tf.ones([fc6l.get_shape()[-1]]), name='gamma')
        #     beta = tf.Variable(tf.zeros([fc6l.get_shape()[-1]]), name='beta')
        #     moving_mean = tf.Variable(tf.zeros([fc6l.get_shape()[-1]]), trainable=False, name='moving_mean')
        #     moving_variance = tf.Variable(tf.ones([fc6l.get_shape()[-1]]), trainable=False, name='moving_variance')
        #     print('fc6 bn state: create')

        # bn = batch_norm_layer(fc6l,
        #                       gamma=gamma,
        #                       beta=beta,
        #                       pop_mean=moving_mean,
        #                       pop_variance=moving_variance,
        #                       is_training=is_training,
        #                       name=scope)
        # fc6 = tf.nn.relu(bn)
        fc6 = tf.nn.relu(fc6l)
        fc6 = tf.cond(stage > 0, lambda: fc6, lambda: tf.nn.dropout(fc6, 0.5))
        # fc6o = tf.nn.relu(fc6l)

        # tf.summary.histogram('/weights', fc6w)
        # tf.summary.histogram('/biases', fc6b)
        # deep_param_img['fc6'] = [fc6w, fc6b, gamma, beta, moving_mean, moving_variance]
        deep_param_img['fc6'] = [fc6w, fc6b]
        # train_layers += [fc6w, gamma, beta]
        train_layers['weights'].append(fc6w)
        train_layers['biases'].append(fc6b)

    # FC7
    # Output 4096
    with tf.name_scope('fc7'):
        fc7w = tf.Variable(net_data['fc7'][0], name='weights')
        fc7b = tf.Variable(net_data['fc7'][1], name='biases')
        fc7l = tf.nn.bias_add(tf.matmul(fc6, fc7w), fc7b)
        # fc7l = tf.matmul(fc6, fc7w)

        # try:
        #     gamma = tf.Variable(net_data['fc7'][2], name='gamma')
        #     beta = tf.Variable(net_data['fc7'][3], name='beta')
        #     moving_mean = tf.Variable(net_data['fc7'][4], name='moving_mean')
        #     moving_variance = tf.Variable(net_data['fc7'][5], name='moving_variance')
        #     print('fc7 bn state: restore')
        # except:
        #     gamma = tf.Variable(tf.ones([fc7l.get_shape()[-1]]), name='gamma')
        #     beta = tf.Variable(tf.zeros([fc7l.get_shape()[-1]]), name='beta')
        #     moving_mean = tf.Variable(tf.zeros([fc7l.get_shape()[-1]]), trainable=False, name='moving_mean')
        #     moving_variance = tf.Variable(tf.ones([fc7l.get_shape()[-1]]), trainable=False, name='moving_variance')
        #     print('fc7 bn state: create')
        #
        # bn = batch_norm_layer(fc7l,
        #                       gamma=gamma,
        #                       beta=beta,
        #                       pop_mean=moving_mean,
        #                       pop_variance=moving_variance,
        #                       is_training=is_training,
        #                       name=scope)
        # fc7 = tf.nn.relu(out)
        fc7 = tf.nn.relu(fc7l)
        fc7 = tf.cond(stage > 0, lambda: fc7, lambda: tf.nn.dropout(fc7, 0.5))

        # tf.summary.histogram(scope + '/weights', fc7w)
        # tf.summary.histogram(scope + '/biases', fc7b)
        # deep_param_img['fc7'] = [fc7w, fc7b, gamma, beta, moving_mean, moving_variance]
        deep_param_img['fc7'] = [fc7w, fc7b]
        # train_layers += [fc7w, gamma, beta]
        train_layers['weights'].append(fc7w)
        train_layers['biases'].append(fc7b)

    # FC8
    # Output output_dim
    with tf.name_scope('fc8'):
        # Differ train and val stage by 'fc8' as key
        if 'fc8' in net_data:
            print('fc8 state: restore')
            fc8w = tf.Variable(net_data['fc8'][0], name='weights')
            fc8b = tf.Variable(net_data['fc8'][1], name='biases')
        else:
            print('fc8 state: train')
            fc8w = tf.Variable(tf.random_normal([4096, output_dim],
                                                dtype=tf.float32,
                                                stddev=1e-2), name='weights')
            fc8b = tf.Variable(tf.constant(0.0, shape=[output_dim],
                                           dtype=tf.float32), name='biases')
        fc8l = tf.nn.bias_add(tf.matmul(fc7, fc8w), fc8b)
        # fc8l = tf.matmul(fc7, fc8w)

        # try:
        #     gamma = tf.Variable(net_data['fc8'][2], name='gamma')
        #     beta = tf.Variable(net_data['fc8'][3], name='beta')
        #     moving_mean = tf.Variable(net_data['fc8'][4], name='moving_mean')
        #     moving_variance = tf.Variable(net_data['fc8'][5], name='moving_variance')
        #     print('fc8 bn state: restore')
        # except:
        #     gamma = tf.Variable(tf.ones([fc8l.get_shape()[-1]]), name='gamma')
        #     beta = tf.Variable(tf.zeros([fc8l.get_shape()[-1]]), name='beta')
        #     moving_mean = tf.Variable(tf.zeros([fc8l.get_shape()[-1]]), trainable=False, name='moving_mean')
        #     moving_variance = tf.Variable(tf.ones([fc8l.get_shape()[-1]]), trainable=False, name='moving_variance')
        #     print('fc8 bn state: create')
        #
        # bn = batch_norm_layer(fc8l,
        #                       gamma=gamma,
        #                       beta=beta,
        #                       pop_mean=moving_mean,
        #                       pop_variance=moving_variance,
        #                       is_training=is_training,
        #                       name=scope)
        if with_tanh:
            fc8_t = tf.nn.tanh(fc8l)
        else:
            fc8_t = fc8l

        def val_fn1():
            concated = tf.concat([tf.expand_dims(i, 0)
                                  for i in tf.split(fc8_t, 2, 0)], 0)
            return tf.reduce_mean(concated, 0)

        fc8 = tf.cond(stage > 0, val_fn1, lambda: fc8_t)

        # tf.summary.histogram(scope + '/weights', fc8w)
        # tf.summary.histogram(scope + '/biases', fc8b)
        deep_param_img['fc8'] = [fc8w, fc8b]
        # deep_param_img['fc8'] = [fc8w, fc8b, gamma, beta, moving_mean, moving_variance]
        train_last_layer['weights'].append(fc8w)
        train_last_layer['biases'].append(fc8b)
        # train_last_layer += [fc8w, gamma, beta]

    bn_update_ops = tf.get_collection(tf.GraphKeys.UPDATE_OPS)

    # 添加网络总所有的 weights tf.GraphKeys.WEIGHTS 中以便正则化
    # [tf.add_to_collection(tf.GraphKeys.WEIGHTS, it) for it in tf.trainable_variables()[:-2] if 'weights' in str(it)]
    # [tf.add_to_collection(tf.GraphKeys.WEIGHTS, it) for it in train_layers['weights']+train_last_layer['weights']]
    # for it in tf.get_collection(tf.GraphKeys.WEIGHTS):
    #     print(it)
    # deep_param_img = tf.global_variables()
    # train_layers = tf.trainable_variables()[:-2]

    # print(bn_update_ops)
    # for index, it in enumerate(train_layers):
    #     print(it, [x.name for x in train_layers[it]])
    # for it in deep_param_img.keys():
    #     print([x.name for x in deep_param_img[it]])
    # print(list(deep_param_img.values()))
    # a = [x for j in train_layers.values() for x in j]
    # for i in tf.trainable_variables():
    #     print(i)
    # exit()

    print("img model loading finished")
    # Return outputs
    return fc8, deep_param_img, train_layers, train_last_layer