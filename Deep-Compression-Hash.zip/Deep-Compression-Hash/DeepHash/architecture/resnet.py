import tensorflow as tf


def group_normalization(inputs, training, group=32, gn_epsilon=1e-5, scope=None):
    with tf.variable_scope(scope, 'group_normalization', [inputs], reuse=tf.AUTO_REUSE):
        input_shape = tf.shape(inputs)
        _, H, W, C = inputs.get_shape().as_list()
        gamma = tf.get_variable('scale', shape=[C], dtype=tf.float32, initializer=tf.ones_initializer(),
                                    trainable=training)
        beta = tf.get_variable('bias', shape=[C], dtype=tf.float32, initializer=tf.zeros_initializer(),
                                   trainable=training)
        inputs = tf.reshape(inputs, [-1, input_shape[1], input_shape[2], group, C // group], name='unpack')
        mean, var = tf.nn.moments(inputs, [1, 2, 4], keep_dims=True)
        inputs = (inputs - mean) / tf.sqrt(var + gn_epsilon)
        inputs = tf.reshape(inputs, input_shape, name='pack')
        gamma = tf.reshape(gamma, [1, 1, 1, C], name='reshape_gamma')
        beta = tf.reshape(beta, [1, 1, 1, C], name='reshape_beta')

        return inputs * gamma + beta

def fc_group_normalization(inputs, training, group=32, gn_epsilon=1e-5, scope=None):
    with tf.variable_scope(scope, 'group_normalization', [inputs], reuse=tf.AUTO_REUSE):
        input_shape = tf.shape(inputs)
        _, C = inputs.get_shape().as_list()
        gamma = tf.get_variable('scale', shape=[C], dtype=tf.float32, initializer=tf.ones_initializer(),
                                    trainable=training)
        beta = tf.get_variable('bias', shape=[C], dtype=tf.float32, initializer=tf.zeros_initializer(),
                                   trainable=training)
        inputs = tf.reshape(inputs, [-1, group, C // group], name='unpack')
        mean, var = tf.nn.moments(inputs, [2], keep_dims=True)
        inputs = (inputs - mean) / tf.sqrt(var + gn_epsilon)
        inputs = tf.reshape(inputs, input_shape, name='pack')
        gamma = tf.reshape(gamma, [1, C], name='reshape_gamma')
        beta = tf.reshape(beta, [1, C], name='reshape_beta')

        return inputs * gamma + beta

class ResNetGN(object):
    def __init__(self, depth=50, data_format='channels_last', gn_epsilon=1e-5):
        super(ResNetGN, self).__init__()
        self._depth = depth
        self._group = 32
        self._data_format = data_format
        self._gn_epsilon = gn_epsilon
        self._conv_initializer = tf.glorot_uniform_initializer
        self._conv_bn_initializer = tf.glorot_uniform_initializer
        self._block_settings = { # 每个block卷积块个数
            50:  (3, 4, 6,  3),
            101: (3, 4, 23, 3),
        }
    # BGR, [-128, 128]
    def get_model(self, inputs, training=False):
        with tf.variable_scope('resnet', [inputs]):
            input_depth = [128, 256, 512, 1024] # the input depth of the the first block is dummy input
            num_units = self._block_settings[self._depth]

            # with tf.variable_scope('block_0', [inputs]) as sc:
            #     if self._data_format == 'channels_first':
            #         inputs = tf.pad(inputs, paddings = [[0, 0], [0, 0], [3, 3], [3, 3]], name='padding_conv1')
            #     else:
            #         inputs = tf.pad(inputs, paddings = [[0, 0], [3, 3], [3, 3], [0, 0]], name='padding_conv1')
            #     inputs = self.conv_gn_relu(inputs, input_depth[0] // 2, (7, 7), (2, 2), 'conv_1', training, reuse=None, padding='valid')
            #     if self._data_format == 'channels_first':
            #         inputs = tf.pad(inputs, paddings = [[0, 0], [0, 0], [1, 1], [1, 1]], constant_values=float('-Inf'), name='padding_pool')
            #     else:
            #         inputs = tf.pad(inputs, paddings = [[0, 0], [1, 1], [1, 1], [0, 0]], constant_values=float('-Inf'), name='padding_pool')
            #     inputs = tf.layers.max_pooling2d(inputs, [3, 3], [2, 2], padding='valid', data_format=self._data_format, name='pool_1')

            is_root = True
            for ind, num_unit in enumerate(num_units):
                with tf.variable_scope('block_{}'.format(ind+1), [inputs]):
                    need_reduce = True
                    for unit_index in range(1, num_unit+1):
                        inputs = self.bottleneck_block(inputs, input_depth[ind], 'conv_{}'.format(unit_index), training, need_reduce=need_reduce, is_root=is_root)
                        need_reduce = False
                        is_root = False

            return inputs

    def group_normalization(self, inputs, training, group, scope=None):
        with tf.variable_scope(scope, 'group_normalization', [inputs], reuse=tf.AUTO_REUSE):
            input_shape = tf.shape(inputs)
            if self._data_format == 'channels_last':
                _, H, W, C = inputs.get_shape().as_list()
                gamma = tf.get_variable('scale', shape=[C], dtype=tf.float32, initializer=tf.ones_initializer(), trainable=training)
                beta = tf.get_variable('bias', shape=[C], dtype=tf.float32, initializer=tf.zeros_initializer(), trainable=training)
                inputs = tf.reshape(inputs, [-1, input_shape[1], input_shape[2], group, C // group], name='unpack')
                mean, var = tf.nn.moments(inputs, [1, 2, 4], keep_dims=True)
                inputs = (inputs - mean) / tf.sqrt(var + self._gn_epsilon)
                inputs = tf.reshape(inputs, input_shape, name='pack')
                gamma = tf.reshape(gamma, [1, 1, 1, C], name='reshape_gamma')
                beta = tf.reshape(beta, [1, 1, 1, C], name='reshape_beta')
                return inputs * gamma + beta
            else:
                _, C, H, W = inputs.get_shape().as_list()
                gamma = tf.get_variable('scale', shape=[C], dtype=tf.float32, initializer=tf.ones_initializer(), trainable=training)
                beta = tf.get_variable('bias', shape=[C], dtype=tf.float32, initializer=tf.zeros_initializer(), trainable=training)
                inputs = tf.reshape(inputs, [-1, group, C // group, input_shape[2], input_shape[3]], name='unpack')
                mean, var = tf.nn.moments(inputs, [2, 3, 4], keep_dims=True)
                inputs = (inputs - mean) / tf.sqrt(var + self._gn_epsilon)
                inputs = tf.reshape(inputs, input_shape, name='pack')
                gamma = tf.reshape(gamma, [1, C, 1, 1], name='reshape_gamma')
                beta = tf.reshape(beta, [1, C, 1, 1], name='reshape_beta')
                return inputs * gamma + beta

    def bottleneck_block(self, inputs, filters, scope, training, need_reduce=True, is_root=False, reuse=None):
        with tf.variable_scope(scope, 'bottleneck_block', [inputs]):
            strides = 1 if (not need_reduce) or is_root else 2
            shortcut = self.conv_gn(inputs, filters * 2, (1, 1), (strides, strides), 'shortcut', training, padding='valid', reuse=reuse) if need_reduce else inputs

            inputs = self.conv_gn_relu(inputs, filters // 2, (1, 1), (1, 1), 'reduce', training, reuse=reuse)
            if self._data_format == 'channels_first':
                inputs = tf.pad(inputs, paddings = [[0, 0], [0, 0], [1, 1], [1, 1]], name='padding_conv_3x3')
            else:
                inputs = tf.pad(inputs, paddings = [[0, 0], [1, 1], [1, 1], [0, 0]], name='padding_conv_3x3')
            inputs = self.conv_gn_relu(inputs, filters // 2, (3, 3), (strides, strides), 'block_3x3', training, padding='valid', reuse=reuse)
            inputs = self.conv_gn(inputs, filters * 2, (1, 1), (1, 1), 'increase', training, reuse=reuse)

            return tf.nn.relu(inputs + shortcut)

    def conv_relu(self, inputs, filters, kernel_size, strides, scope, padding='same', reuse=None):
        with tf.variable_scope(scope, 'conv_relu', [inputs]):
            inputs = tf.layers.conv2d(inputs, filters, kernel_size, strides=strides,
                                name='conv2d', use_bias=True, padding=padding,
                                data_format=self._data_format, activation=tf.nn.relu,
                                kernel_initializer=self._conv_initializer(),
                                bias_initializer=tf.zeros_initializer(), reuse=reuse)
            return inputs
    def conv_gn_relu(self, inputs, filters, kernel_size, strides, scope, training, padding='same', reuse=None):
        with tf.variable_scope(scope, 'conv_gn_relu', [inputs]):
            inputs = tf.layers.conv2d(inputs, filters, kernel_size, strides=strides,
                                name='conv2d', use_bias=False, padding=padding,
                                data_format=self._data_format, activation=None,
                                kernel_initializer=self._conv_initializer(),
                                bias_initializer=None, reuse=reuse)

            inputs = self.group_normalization(inputs, training, self._group, scope='gn')
            return tf.nn.relu(inputs)
    def gn_relu(self, inputs, scope, training, reuse=None):
        with tf.variable_scope(scope, 'gn_relu', [inputs]):
            inputs = self.group_normalization(inputs, training, self._group, scope='gn')
            return tf.nn.relu(inputs)
    def conv_gn(self, inputs, filters, kernel_size, strides, scope, training, padding='same', reuse=None):
        with tf.variable_scope(scope, 'conv_gn', [inputs]):
            inputs = tf.layers.conv2d(inputs, filters, kernel_size, strides=strides,
                                name='conv2d', use_bias=False, padding=padding,
                                data_format=self._data_format, activation=None,
                                kernel_initializer=self._conv_initializer(),
                                bias_initializer=None, reuse=reuse)
            inputs = self.group_normalization(inputs, training, self._group, scope='gn')
            return inputs


def comp_resnet_layers(img, batch_size, output_dim, stage, is_training, model_weights, with_tanh=True, val_batch_size=32):
    """

    :param img:
    :param batch_size:
    :param output_dim:
    :param stage:
    :param model_weights:
    :param with_tanh:
    :param val_batch_size:
    :return:
    """

    # Randomly crop a [height, width] section of each image
    with tf.name_scope('preprocess'):

        centers = tf.Variable([-2.7752876, -4.6336412, -0.1840482, -1.3905534, 3.3731883, 1.3394068], name='centers',
                              trainable=False)
        num_centers = centers.get_shape().as_list()[-1]

        # intput code: BCHW (B,64,32,32)
        # reshape (B, C, h, w) to (B, C, m=h*w)
        x_shape_BCwh = tf.shape(img)

        B = x_shape_BCwh[0]  # B is not necessarily static
        C = int(img.shape[1])  # C is static
        img = tf.reshape(img, [B, C, -1])

        phi_hard = tf.one_hot(img, depth=num_centers, axis=-1, dtype=tf.float32)

        img = tf.reshape(tf.reduce_sum(phi_hard * centers, axis=3), x_shape_BCwh)

        # reshape to [B,H,W,C]
        img = tf.transpose(img, [0, 2, 3, 1])

        def train_fn():
            return tf.stack([tf.image.random_flip_left_right(each) for each in tf.unstack(img, batch_size)])

        def val_fn():
            unstacked = tf.unstack(img, val_batch_size)

            def distort(f): return tf.stack(
                [f(each) for each in unstacked])

            def distort_raw(): return distort(lambda x: x)

            def distort_flip_left_right(): return distort(tf.image.flip_left_right)
            def distort_flip_up_down(): return distort(tf.image.flip_up_down)
            def distort_transpose_image(): return distort(tf.image.transpose_image)

            distorted = tf.concat([distort_flip_left_right(),
                                   # distort_flip_up_down(),
                                   # distort_transpose_image(),
                                   distort_raw()],
                                  0)
            return distorted

        distorted = tf.cond(stage > 0, val_fn, train_fn)

    # resnet_GN 4x4x2048
    with tf.name_scope('resnet'):
        out = ResNetGN().get_model(distorted, training=is_training)

    # pool_last 1x1x2048
    with tf.name_scope('pool_last'):
        pool_last = tf.reduce_mean(out, [1, 2], name='pool_last', keepdims=False)
        # pool_last = tf.nn.max_pool(out, ksize=[1, 4, 4, 1], strides=[1, 4, 4, 1], padding='SAME', name='pool_last')
        pool_last = tf.reshape(pool_last, [-1, 2048])

    # fc output_dim
    with tf.name_scope('fc'):
        fc1 = tf.layers.dense(pool_last, units=2048, activation=tf.nn.relu)
        # fc2 = tf.layers.dense(fc1, units=2048, activation=tf.nn.relu)
        hash_layer = tf.layers.dense(fc1, units=output_dim, activation=tf.nn.relu)
        # fc1 = tf.nn.relu(fc_group_normalization(fc1, training=is_training, scope='gn'))
        # fcl = tf.layers.dense(fc1, units=output_dim, activation=None)
        # fcl = tf.layers.conv2d(pool_last, filters=output_dim, kernel_size=1, strides=1,
        #                         name='conv2d', use_bias=True, padding='SAME', activation=None)

        if with_tanh:
            fc = tf.nn.tanh(hash_layer)
        else:
            fc = hash_layer

    def val_fn1():
        concated = tf.concat([tf.expand_dims(i, 0)
                              for i in tf.split(fc, 2, 0)], 0)
        return tf.reduce_mean(concated, 0)

    outputs = tf.cond(stage > 0, val_fn1, lambda: fc)

    # 添加网络总所有的 weights tf.GraphKeys.WEIGHTS 中以便正则化
    # [tf.add_to_collection(tf.GraphKeys.WEIGHTS, v) for v in tf.trainable_variables() if 'gn' not in v.name]

    deep_param_img = tf.global_variables()[1:]
    train_last_layer = deep_param_img[-6:] # fc trainable variables
    train_layers = list(set(deep_param_img) - set(train_last_layer))

    # for i in train_last_layer:
    #     print(i.name)

    # print(tf.get_collection(tf.GraphKeys.WEIGHTS))
    # exit()

    print("img model loading finished")
    # Return outputs
    return outputs, deep_param_img, train_layers, train_last_layer


