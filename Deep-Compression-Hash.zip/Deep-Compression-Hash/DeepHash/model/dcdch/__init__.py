from .util import Dataset
from .dcdch import DCDCH

def train(train_img, database_img, query_img, config):
    model = DCDCH(config, mode='train')
    # model = DCDCH(config)
    img_database = Dataset(database_img, config.output_dim)
    img_query = Dataset(query_img, config.output_dim)
    img_train = Dataset(train_img, config.output_dim)
    model.train(img_train)
    return model.save_file

def validation(database_img, query_img, config):
    model = DCDCH(config, mode='validation')
    # model = DCDCH(config)
    img_database = Dataset(database_img, config.output_dim)
    img_query = Dataset(query_img, config.output_dim)
    return model.validation(img_query, img_database, config.R)
